import { NextResponse } from "next/server";
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function GET() {
  console.log('E-posta gönderme testi başlatılıyor...');
  console.log('RESEND_API_KEY:', process.env.RESEND_API_KEY ? 'Mevcut' : 'Eksik');
  console.log('EMAIL_FROM:', process.env.EMAIL_FROM);

  try {
    console.log('Resend ile e-posta gönderiliyor...');
    const data = await resend.emails.send({
      from: 'SummarAI <onay@summarai.com>',
      to: "summar.ai.bot@gmail.com",
      subject: "SummarAI Test E-postası",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2>Test E-postası</h2>
          <p>Merhaba,</p>
          <p>Bu bir test e-postasıdır. Saat: ${new Date().toLocaleString()}</p>
          <p>İyi günler,<br>SummarAI Ekibi</p>
        </div>
      `,
    });

    console.log('E-posta gönderildi:', data);
    return NextResponse.json({ 
      success: true, 
      data,
      timestamp: new Date().toISOString(),
      environment: {
        RESEND_API_KEY: !!process.env.RESEND_API_KEY,
        EMAIL_FROM: process.env.EMAIL_FROM
      }
    });
  } catch (error) {
    console.error('E-posta gönderme hatası:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : "E-posta gönderilemedi",
        timestamp: new Date().toISOString(),
        environment: {
          RESEND_API_KEY: !!process.env.RESEND_API_KEY,
          EMAIL_FROM: process.env.EMAIL_FROM
        }
      },
      { status: 500 }
    );
  }
} 